pub const CONFIG: &str = "config";
pub const GLOBAL: &str = "global";
pub const METADATA: &str = "metadata";
pub const LAMPORT_DECIMALS: u8 = 9;
pub const TOKEN_LAUNCH: &str = "token_launch";
pub const GAME_GROUND: &str = "BONDING_CURVE";
